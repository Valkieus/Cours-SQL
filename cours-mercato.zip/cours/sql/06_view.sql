USE Mercato;
GO
 
CREATE VIEW dbo.vw_PlayerPublic AS
SELECT
    PlayerID,
    FirstName,
    LastName,
    CreatedAt,
    Speed,
    IsAvailable,
    CurrentClubID
FROM dbo.Player;
GO  
