IF DB_ID('Boutique') IS NOT NULL
BEGIN
    ALTER DATABASE Boutique SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE Boutique;
END
GO
CREATE DATABASE Boutique
ON PRIMARY (
    NAME = Boutique_data,
    FILENAME = '/var/opt/mssql/data/Boutique.mdf',
    SIZE = 128MB,
    FILEGROWTH = 64MB
),
FILEGROUP FG_DATA
(
    NAME = Boutique_fg1,
    FILENAME = '/var/opt/mssql/data/Boutique1.ndf',
    SIZE = 128MB,
    FILEGROWTH = 64MB
)
LOG ON (
    NAME = Boutique_log,
    FILENAME = '/var/opt/mssql/log/Boutique.ldf',
    SIZE = 64MB,
    FILEGROWTH = 32MB
)
GO
