USE Mercato;
GO

SELECT
    p.PlayerID,
    p.FirstName,
    p.LastName,
    c.Name AS Club,
    c.Country,
    p.Speed,
    p.Price,
    p.IsAvailable,
    p.CreatedAt
FROM dbo.Player p
LEFT JOIN dbo.PlayerCurrentClub c
    ON p.CurrentClubID = c.PlayerCurrentClubID;
GO
