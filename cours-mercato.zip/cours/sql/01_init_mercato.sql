IF DB_ID('Mercato') IS NOT NULL
BEGIN
    ALTER DATABASE Mercato SET SINGLE_USER WITH ROLLBACK IMMEDIATE;

    DROP DATABASE Mercato;
END
GO

CREATE DATABASE Mercato 
ON PRIMARY (
    NAME = Mercato_data,
    FILENAME = '/var/opt/mssql/data/Mercato.mdf',
    SIZE = 128MB,
    FILEGROWTH = 64MB
),
FILEGROUP FG_DATA (
    NAME = Mercato_data_fg1,
    FILENAME = '/var/opt/mssql/data/Mercato.ndf',
    SIZE = 128MB,
    FILEGROWTH = 64MB
) LOG ON (
    NAME = Mercato_data_log,
    FILENAME = '/var/opt/mssql/log/Mercato.ldf',
    SIZE = 64MB,
    FILEGROWTH = 32MB
);
