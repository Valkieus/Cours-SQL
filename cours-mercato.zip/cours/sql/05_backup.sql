DECLARE @backupFile NVARCHAR(200);
DECLARE @sql NVARCHAR(500);

SET @backupFile = '/backups/Mercato_FULL_' 
    + FORMAT(GETDATE(), 'yyyyMMdd_HHmmss') 
    + '.bak';

SET @sql = 'BACKUP DATABASE [Mercato] TO DISK = ''' + @backupFile + '''
    WITH INIT,
        COMPRESSION,
        CHECKSUM,
        STATS = 10;';

PRINT 'Sauvegarde vers : ' + @backupFile;
EXEC sp_executesql @sql;
GO
