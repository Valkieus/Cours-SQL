USE Mercato;
GO

CREATE TABLE dbo.PlayerCurrentClub(
    PlayerCurrentClubID INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
    Name NVARCHAR(50) NOT NULL,
    Country NVARCHAR(50) NOT NULL
);

CREATE TABLE dbo.Player (
    PlayerID INT IDENTITY(1,1) NOT NULL,
    CONSTRAINT PK_PlayerID PRIMARY KEY(PlayerID),
    FirstName NVARCHAR(20) NOT NULL,
    LastName NVARCHAR(40) NOT NULL,
    CreatedAt DATETIME2 DEFAULT SYSDATETIME() NOT NULL,
    Speed DECIMAL(5,1) NOT NULL,
    Price INT NOT NULL,
    IsAvailable BIT DEFAULT 0,
    CurrentClubID INT NULL,
    CONSTRAINT FK_PlayerCurrentClub FOREIGN KEY(CurrentClubID)
        REFERENCES dbo.PlayerCurrentClub(PlayerCurrentClubID)
        ON DELETE SET NULL ON UPDATE NO ACTION
);
GO
