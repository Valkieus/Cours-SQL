USE Mercato;
GO

-- 1. Insertion des 10 grands clubs européens
INSERT INTO dbo.PlayerCurrentClub (Name, Country)
VALUES
('Real Madrid', 'Espagne'),
('FC Barcelona', 'Espagne'),
('Manchester City', 'Angleterre'),
('Liverpool', 'Angleterre'),
('Paris Saint-Germain', 'France'),
('Bayern Munich', 'Allemagne'),
('Arsenal', 'Angleterre'),
('Chelsea', 'Angleterre'),
('Inter Milan', 'Italie'),
('Juventus', 'Italie');
GO

-- 2. Insertion du 11 titulaire pour chaque club (110 joueurs)
INSERT INTO dbo.Player (FirstName, LastName, Speed, Price, IsAvailable, CurrentClubID)
VALUES
-- REAL MADRID (CurrentClubID = 1)
('Thibaut', 'Courtois', 5.5, 28000000, 0, 1),
('Dani', 'Carvajal', 8.0, 12000000, 0, 1),
('Éder', 'Militão', 8.3, 60000000, 0, 1),
('Antonio', 'Rüdiger', 8.8, 25000000, 0, 1),
('Ferland', 'Mendy', 8.7, 22000000, 0, 1),
('Federico', 'Valverde', 8.9, 130000000, 0, 1),
('Aurélien', 'Tchouaméni', 7.8, 100000000, 1, 1),
('Jude', 'Bellingham', 8.5, 180000000, 0, 1),
('Rodrygo', 'Goes', 9.1, 110000000, 1, 1),
('Kylian', 'Mbappé', 9.7, 180000000, 0, 1),
('Vinícius', 'Júnior', 9.6, 200000000, 0, 1),

-- FC BARCELONA (CurrentClubID = 2)
('Marc-André', 'ter Stegen', 5.2, 20000000, 0, 2),
('Jules', 'Koundé', 8.2, 55000000, 0, 2),
('Ronald', 'Araújo', 8.8, 70000000, 0, 2),
('Pau', 'Cubarsí', 7.2, 40000000, 0, 2),
('Alejandro', 'Balde', 9.3, 40000000, 1, 2),
('Frenkie', 'de Jong', 8.1, 60000000, 1, 2),
('Gavi', '', 8.0, 90000000, 0, 2),
('Pedri', '', 8.2, 120000000, 1, 2),
('Lamine', 'Yamal', 9.2, 180000000, 0, 2),
('Robert', 'Lewandowski', 7.3, 15000000, 0, 2),
('Raphinha', '', 8.9, 60000000, 0, 2),

-- MANCHESTER CITY (CurrentClubID = 3)
('Ederson', 'Moraes', 6.0, 35000000, 0, 3),
('Kyle', 'Walker', 9.3, 13000000, 0, 3),
('Rúben', 'Dias', 7.2, 80000000, 0, 3),
('Manuel', 'Akanji', 8.1, 45000000, 0, 3),
('Josko', 'Gvardiol', 8.3, 75000000, 0, 3),
('Rodri', 'Hernández', 7.2, 130000000, 0, 3),
('Kevin', 'De Bruyne', 7.5, 45000000, 1, 3),
('Bernardo', 'Silva', 7.9, 70000000, 1, 3),
('Phil', 'Foden', 8.7, 140000000, 1, 3),
('Erling', 'Haaland', 9.0, 200000000, 0, 3),
('Jérémy', 'Doku', 9.6, 65000000, 0, 3),

-- LIVERPOOL FC (CurrentClubID = 4)
('Alisson', 'Becker', 5.8, 28000000, 0, 4),
('Trent', 'Alexander-Arnold', 8.1, 70000000, 1, 4),
('Ibrahima', 'Konaté', 8.4, 45000000, 0, 4),
('Virgil', 'van Dijk', 7.8, 30000000, 1, 4),
('Andrew', 'Robertson', 8.3, 30000000, 0, 4),
('Alexis', 'Mac Allister', 7.4, 75000000, 0, 4),
('Dominik', 'Szoboszlai', 8.5, 75000000, 0, 4),
('Ryan', 'Gravenberch', 8.0, 40000000, 0, 4),
('Mohamed', 'Salah', 9.0, 55000000, 1, 4),
('Darwin', 'Núñez', 9.2, 65000000, 1, 4),
('Luis', 'Díaz', 9.1, 80000000, 0, 4),

-- PARIS SAINT-GERMAIN (CurrentClubID = 5)
('Gianluigi', 'Donnarumma', 5.5, 40000000, 0, 5),
('Achraf', 'Hakimi', 9.5, 60000000, 0, 5),
('Marquinhos', '', 7.8, 50000000, 0, 5),
('Willian', 'Pacho', 8.0, 40000000, 0, 5),
('Nuno', 'Mendes', 9.2, 55000000, 0, 5),
('Vitinha', '', 8.0, 55000000, 0, 5),
('João', 'Neves', 8.2, 60000000, 0, 5),
('Warren', 'Zaïre-Emery', 8.1, 60000000, 0, 5),
('Ousmane', 'Dembélé', 9.4, 60000000, 0, 5),
('Gonçalo', 'Ramos', 7.9, 50000000, 1, 5),
('Bradley', 'Barcola', 9.3, 65000000, 0, 5),

-- BAYERN MUNICH (CurrentClubID = 6)
('Manuel', 'Neuer', 5.0, 4000000, 0, 6),
('Joshua', 'Kimmich', 7.3, 50000000, 1, 6),
('Dayot', 'Upamecano', 8.6, 45000000, 0, 6),
('Min-jae', 'Kim', 8.2, 45000000, 0, 6),
('Alphonso', 'Davies', 9.6, 50000000, 1, 6),
('Aleksandar', 'Pavlovic', 7.5, 50000000, 0, 6),
('Michael', 'Olise', 8.8, 65000000, 0, 6),
('Jamal', 'Musiala', 9.1, 130000000, 0, 6),
('Leroy', 'Sané', 9.3, 60000000, 1, 6),
('Harry', 'Kane', 7.8, 100000000, 1, 6),
('Kingsley', 'Coman', 9.2, 40000000, 1, 6),

-- ARSENAL (CurrentClubID = 7)
('David', 'Raya', 5.4, 35000000, 0, 7),
('Ben', 'White', 7.9, 55000000, 0, 7),
('William', 'Saliba', 8.3, 80000000, 0, 7),
('Gabriel', 'Magalhães', 7.8, 75000000, 0, 7),
('Jurriën', 'Timber', 8.2, 38000000, 0, 7),
('Declan', 'Rice', 7.9, 120000000, 1, 7),
('Thomas', 'Partey', 7.3, 18000000, 1, 7),
('Martin', 'Ødegaard', 7.8, 110000000, 0, 7),
('Bukayo', 'Saka', 9.1, 140000000, 0, 7),
('Kai', 'Havertz', 8.1, 75000000, 0, 7),
('Gabriel', 'Martinelli', 9.4, 60000000, 1, 7),

-- CHELSEA (CurrentClubID = 8)
('Robert', 'Sánchez', 5.3, 20000000, 0, 8),
('Malo', 'Gusto', 8.8, 35000000, 0, 8),
('Wesley', 'Fofana', 8.1, 25000000, 0, 8),
('Levi', 'Colwill', 7.6, 50000000, 0, 8),
('Marc', 'Cucurella', 8.0, 30000000, 0, 8),
('Moisés', 'Caicedo', 8.0, 75000000, 0, 8),
('Enzo', 'Fernández', 8.0, 75000000, 1, 8),
('Cole', 'Palmer', 8.6, 130000000, 0, 8),
('Noni', 'Madueke', 8.9, 35000000, 1, 8),
('Nicolas', 'Jackson', 8.7, 40000000, 1, 8),
('Pedro', 'Neto', 9.2, 55000000, 0, 8),

-- INTER MILAN (CurrentClubID = 9)
('Yann', 'Sommer', 5.1, 5000000, 0, 9),
('Benjamin', 'Pavard', 7.6, 45000000, 0, 9),
('Francesco', 'Acerbi', 6.5, 3000000, 0, 9),
('Alessandro', 'Bastoni', 7.8, 70000000, 0, 9),
('Denzel', 'Dumfries', 8.9, 24000000, 1, 9),
('Federico', 'Dimarco', 8.5, 50000000, 0, 9),
('Hakan', 'Çalhanoğlu', 7.2, 45000000, 0, 9),
('Nicolò', 'Barella', 8.3, 80000000, 0, 9),
('Henrikh', 'Mkhitaryan', 7.5, 6000000, 0, 9),
('Lautaro', 'Martínez', 8.5, 100000000, 0, 9),
('Marcus', 'Thuram', 9.1, 75000000, 1, 9),

-- JUVENTUS (CurrentClubID = 10)
('Michele', 'Di Gregorio', 5.3, 18000000, 0, 10),
('Nicolò', 'Savona', 7.8, 7000000, 0, 10),
('Gleison', 'Bremer', 8.2, 60000000, 0, 10),
('Pierre', 'Kalulu', 8.4, 20000000, 0, 10),
('Andrea', 'Cambiaso', 8.2, 30000000, 0, 10),
('Manuel', 'Locatelli', 7.1, 28000000, 0, 10),
('Teun', 'Koopmeiners', 7.7, 55000000, 0, 10),
('Khéphren', 'Thuram', 8.1, 35000000, 0, 10),
('Francisco', 'Conceição', 9.0, 22000000, 1, 10),
('Dušan', 'Vlahović', 8.4, 65000000, 1, 10),
('Kenan', 'Yildiz', 8.6, 40000000, 0, 10);
GO
