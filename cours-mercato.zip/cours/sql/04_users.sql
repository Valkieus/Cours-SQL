USE master;
GO

CREATE LOGIN boris WITH PASSWORD = 'B0ris_Secure!2026';
CREATE LOGIN caroline WITH PASSWORD = 'Car0line_Secure!2026';
GO

USE Mercato;
GO

CREATE USER boris FOR LOGIN boris;
CREATE USER caroline FOR LOGIN caroline;
GO

ALTER ROLE db_datareader ADD MEMBER boris;
ALTER ROLE db_datareader ADD MEMBER caroline;
GO
