USE msdb;
GO

IF EXISTS (SELECT 1 FROM msdb.dbo.sysjobs WHERE name = N'Maintenance_Mercato')
    EXEC dbo.sp_delete_job @job_name = N'Maintenance_Mercato';
GO

EXEC dbo.sp_add_job
    @job_name = N'Maintenance_Mercato',
    @description = N'Pipeline : sauvegarde, réindexation, purge.';
GO

EXEC dbo.sp_add_jobstep
    @job_name = N'Maintenance_Mercato',
    @step_name = N'01 - Sauvegarde',
    @subsystem = N'TSQL',
    @database_name = N'master',
    @command = N'
DECLARE @f nvarchar(260) =
    N''/backups/Mercato_FULL_'' + FORMAT(SYSDATETIME(), ''yyyyMMdd_HHmmss'') + N''.bak'';
BACKUP DATABASE Mercato TO DISK = @f
    WITH INIT, COMPRESSION, CHECKSUM, STATS = 10;',
    @on_success_action = 3,
    @on_fail_action = 2;
GO

EXEC dbo.sp_add_jobstep
    @job_name = N'Maintenance_Mercato',
    @step_name = N'02 - Réindexation',
    @subsystem = N'TSQL',
    @database_name = N'Mercato',
    @command = N'
DECLARE @sql nvarchar(max) = N'''';
SELECT @sql += N''ALTER INDEX '' + QUOTENAME(i.name) + N'' ON ''
    + QUOTENAME(SCHEMA_NAME(o.schema_id)) + N''.'' + QUOTENAME(o.name)
    + CASE WHEN ps.avg_fragmentation_in_percent > 30 THEN N'' REBUILD;''
        ELSE N'' REORGANIZE;'' END + CHAR(10)
FROM sys.dm_db_index_physical_stats(DB_ID(), NULL, NULL, NULL, ''LIMITED'') ps
JOIN sys.indexes i ON i.object_id = ps.object_id AND i.index_id = ps.index_id
JOIN sys.objects o ON o.object_id = i.object_id
WHERE i.index_id > 0
    AND ps.page_count > 8
    AND ps.avg_fragmentation_in_percent > 5;
EXEC sys.sp_executesql @sql;
EXEC sys.sp_updatestats;',
    @on_success_action = 3,
    @on_fail_action = 2;
GO

EXEC dbo.sp_add_jobstep
    @job_name = N'Maintenance_Mercato',
    @step_name = N'03 - Purge des backups',
    @subsystem = N'TSQL',
    @database_name = N'master',
    @command = N'
DECLARE @cutoff nvarchar(30) = CONVERT(nvarchar(30), DATEADD(DAY, -7, SYSDATETIME()), 126);
EXEC master.dbo.xp_delete_file 0, N''/backups'', N''bak'', @cutoff;',
    @on_success_action = 1,
    @on_fail_action = 2;
GO

EXEC dbo.sp_add_jobserver
    @job_name = N'Maintenance_Mercato',
    @server_name = N'(LOCAL)';
GO

EXEC dbo.sp_add_schedule
    @schedule_name = N'Jour_14h',
    @freq_type = 4,
    @freq_interval = 1,
    @active_start_time = 140000;
GO

EXEC dbo.sp_attach_schedule
    @job_name = N'Maintenance_Mercato',
    @schedule_name = N'Jour_14h';
GO

EXEC dbo.sp_help_jobschedule @job_name = N'Maintenance_Mercato';
GO
